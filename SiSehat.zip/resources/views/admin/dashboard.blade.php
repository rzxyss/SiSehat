@extends('layouts.dashboard.app')

@section('content')
    <h6 class="text-lg text-gray-500 font-semibold mb-6">Sample Page</h6>
    <p class="text-sm text-gray-400">This is a sample page</p>
@endsection
