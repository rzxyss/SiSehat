<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('dashboard.obat.store')); ?>">
    <?php echo csrf_field(); ?>
    <div class="mb-6">
        <label class="block text-sm mb-2 text-gray-400">Nama Obat</label>
        <input type="text"
            class="py-3 px-4 text-gray-500 block w-full border-gray-200 rounded-sm text-sm focus:border-blue-600 focus:ring-0 "
            placeholder="Masukan Nama Obat" name="nama_obat">
    </div>
    <div class="mb-6">
        <label class="block text-sm mb-2 text-gray-400">Deskripsi</label>
        <textarea
            class="py-3 px-4 text-gray-500 block w-full border-gray-200 rounded-sm text-sm focus:border-blue-600 focus:ring-0"
            name="deskripsi" cols="30" rows="10" placeholder="Masukan Deskripsi Obat"></textarea>
    </div>
    <div class="mb-6">
        <label class="block text-sm mb-2 text-gray-400">Harga</label>
        <input type="text"
            class="py-3 px-4 text-gray-500 block w-full border-gray-200 rounded-sm text-sm focus:border-blue-600 focus:ring-0 "
            placeholder="Masukan Harga Obat" name="harga">
    </div>
    <div class="mb-6">
        <label class="block text-sm mb-2 text-gray-400">Stok</label>
        <input type="number"
            class="py-3 px-4 text-gray-500 block w-full border-gray-200 rounded-sm text-sm focus:border-blue-600 focus:ring-0 "
            placeholder="Masukan Stok Obat" name="stok">
    </div>
    <div class="mb-6">
        <label class="block text-sm mb-2 text-gray-400">Tanggal Kadaluarsa</label>
        <input type="date"
            class="py-3 px-4 text-gray-500 block w-full border-gray-200 rounded-sm text-sm focus:border-blue-600 focus:ring-0 "
            name="expired">
    </div>
    <button type="submit" class="btn text-base py-2.5 text-white font-medium w-fit hover:bg-blue-700">Submit</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\SiSehat\resources\views/admin/obat/create.blade.php ENDPATH**/ ?>