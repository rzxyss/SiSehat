<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <script src="//unpkg.com/alpinejs" defer></script>
</head>

<body class="font-sans antialiased">
    <nav class="sticky top-0 bg-white shadow-md border-gray-200 z-50">
        <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
            <a href="#" class="flex items-center">
                <span class="text-2xl font-bold text-primary">SiSehat</span>
            </a>

            <button data-collapse-toggle="navbar-menu" type="button"
                class="inline-flex items-center p-2 w-10 h-10 justify-center text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:ring-2 focus:ring-primary"
                aria-controls="navbar-menu" aria-expanded="false">
                <span class="sr-only">Toggle menu</span>
                <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                    viewBox="0 0 17 14">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M1 1h15M1 7h15M1 13h15" />
                </svg>
            </button>

            <div class="hidden w-full md:flex md:items-center md:w-auto" id="navbar-menu">
                <ul
                    class="font-montserrat flex flex-col p-4 md:p-0 mt-4 bg-gray-50 md:flex-row md:space-x-8 md:mt-0 md:bg-transparent md:border-0">
                    <li>
                        <a href="<?php echo e(route('home')); ?>"
                            class="block py-2 px-3 transition-colors md:p-0 <?php echo e(request()->routeIs('home') ? 'text-primary font-semibold' : 'text-gray-900 hover:text-primary'); ?>">
                            Beranda
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('blog.index')); ?>"
                            class="block py-2 px-3 transition-colors md:p-0 <?php echo e(request()->is('blog*') ? 'text-primary font-semibold' : 'text-gray-900 hover:text-primary'); ?>">
                            Blog
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('bmi.index')); ?>"
                            class="block py-2 px-3 transition-colors md:p-0 <?php echo e(request()->routeIs('bmi.*') ? 'text-primary font-semibold' : 'text-gray-900 hover:text-primary'); ?>">
                            BMI
                        </a>
                    </li>
                    <li>
                        <a href="#"
                            class="block py-2 px-3 transition-colors md:p-0 <?php echo e(request()->is('about*') ? 'text-primary font-semibold' : 'text-gray-900 hover:text-primary'); ?>">
                            Tentang Kami
                        </a>
                    </li>
                </ul>
            </div>

            <div class="hidden md:flex items-center space-x-4">
                <a href="/login"
                    class="px-6 py-2 text-primary border-2 border-primary rounded-lg hover:bg-primary hover:text-white transition-colors">
                    Login
                </a>
                <a href="/register"
                    class="px-6 py-2 bg-primary text-white rounded-lg hover:bg-shade1 transition-colors">
                    Registrasi
                </a>
            </div>

            <div class="md:hidden w-full mt-4 hidden" id="navbar-auth">
                <div class="grid grid-cols-2 gap-4">
                    <a href="/login" class="text-center py-2 text-primary border-2 border-primary rounded-lg">
                        Login
                    </a>
                    <a href="/register" class="text-center py-2 bg-primary text-white rounded-lg">
                        Registrasi
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const button = document.querySelector('[data-collapse-toggle="navbar-menu"]');
            const menu = document.getElementById('navbar-menu');
            const auth = document.getElementById('navbar-auth');

            button.addEventListener('click', function() {
                menu.classList.toggle('hidden');
                auth.classList.toggle('hidden');
            });
        });
    </script>

    <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
        <?php echo $__env->yieldContent('home'); ?>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const button = document.querySelector('[data-collapse-toggle="navbar-menu"]');
            const menu = document.getElementById('navbar-menu');
            const auth = document.getElementById('navbar-auth');

            button.addEventListener('click', function() {
                menu.classList.toggle('hidden');
                auth.classList.toggle('hidden');
            });
        });
    </script>
    <?php echo $__env->yieldContent('js'); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\SiSehat\resources\views/layouts/home.blade.php ENDPATH**/ ?>