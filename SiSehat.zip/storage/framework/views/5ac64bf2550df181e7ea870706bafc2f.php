<?php $__env->startSection('content'); ?>
    <h6 class="text-lg text-gray-500 font-semibold mb-6">Sample Page</h6>
    <p class="text-sm text-gray-400">This is a sample page</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\SiSehat\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>