<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('dashboard.dokter.tambah')); ?>"
    class="py-2 px-6 btn text-xs bg-yellow-600 text-white hover:bg-yellow-700 ">
    Tambah Dokter
</a>
<div class="relative overflow-x-auto">
    <!-- table -->
    <table class="text-left w-full whitespace-nowrap text-sm text-gray-500">
        <thead>
            <tr class="text-sm">
                <th scope="col" class="p-4 font-semibold">No</th>
                <th scope="col" class="p-4 font-semibold">Nama Dokter</th>
                <th scope="col" class="p-4 font-semibold">Alamat</th>
                <th scope="col" class="p-4 font-semibold">Jenis Kelamin</th>
                <th scope="col" class="p-4 font-semibold">Tanggal lahir</th>
                <th scope="col" class="p-4 font-semibold">Email</th>
                <th scope="col" class="p-4 font-semibold">No Telp</th>
                <th scope="col" class="p-4 font-semibold">Spesialis</th>
                <th scope="col" class="p-4 font-semibold">Jadwal Praktik</th>
                <th scope="col" class="p-4 font-semibold">Gaji</th>
                <th scope="col" class="p-4 font-semibold">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="p-4">
                    <h3 class="font-bold"><?php echo e($index + 1); ?></h3>
                </td>
                <td class="p-4">
                    <h3 class="font-medium"><?php echo e($d->nama_dokter); ?></h3>
                </td>
                <td class="p-4">
                    <h3 class="font-medium"><?php echo e($d->alamat); ?></h3>
                </td>
                <td class="p-4">
                    <h3 class="font-medium">Rp. <?php echo e($d->jenis_kelamin); ?></h3>
                </td>
                <td class="p-4">
                    <h3 class="font-medium"><?php echo e($d->email); ?></h3>
                </td>
                <td class="p-4">
                    <h3 class="font-medium"><?php echo e($d->no_telp); ?></h3>
                </td>
                <td class="p-4">
                    <h3 class="font-medium"><?php echo e($d->spesialis); ?></h3>
                </td>
                <td class="p-4">
                    <h3 class="font-medium"><?php echo e($d->jadwal_praktik); ?></h3>
                </td>
                <td class="p-4">
                    <h3 class="font-medium"><?php echo e($d->gaji); ?></h3>
                </td>
                <td class="p-4">
                    <h3 class="font-medium">
                        <div class="flex flex-row gap-1 items-center">
                            <a href="<?php echo e(route('dashboard.dokter.edit', $d->id)); ?>"
                                class="py-2 px-6 btn text-xs bg-yellow-600 text-white hover:bg-yellow-700 ">
                                Edit
                            </a>
                            <form method="POST" action="<?php echo e(route('dashboard.dokter.destroy', $d->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                    class="py-2 px-6 btn text-xs bg-red-600 text-white hover:bg-red-700 ">
                                    Hapus
                                </button>
                            </form>
                        </div>
                    </h3>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SiSehat\resources\views/admin/dokter/index.blade.php ENDPATH**/ ?>