<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('dashboard.pasien.tambah')); ?>"
    class="py-2 px-6 btn text-xs bg-yellow-600 text-white hover:bg-yellow-700 ">
    Tambah Pasien
</a>
<div class="relative overflow-x-auto">
    <!-- table -->
    <table class="text-left w-full whitespace-nowrap text-sm text-gray-500">
        <thead>
            <tr class="text-sm">
                <th scope="col" class="p-4 font-semibold">No</th>
                <th scope="col" class="p-4 font-semibold">Nama Pasien</th>
                <th scope="col" class="p-4 font-semibold">Tanggal Lahir</th>
                <th scope="col" class="p-4 font-semibold">Jenis Kelamin</th>
                <th scope="col" class="p-4 font-semibold">No. Telepon</th>
                <th scope="col" class="p-4 font-semibold">Alamat</th>
                <th scope="col" class="p-4 font-semibold">Riwayat Alergi</th>
                <th scope="col" class="p-4 font-semibold">Riwayat Penyakit</th>
                <th scope="col" class="p-4 font-semibold">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pasien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="p-4">
                    <h3 class="font-bold"><?php echo e($index + 1); ?></h3>
                </td>
                <td class="p-4">
                    <h3 class="font-medium"><?php echo e($p->nama_pasien); ?></h3>
                </td>
                <td class="p-4">
                    <h3 class="font-medium"><?php echo e($p->tgl_lahir); ?></h3>
                </td>
                <td class="p-4">
                    <h3 class="font-medium"><?php echo e(ucfirst(str_replace('_', ' ', $p->jenis_kelamin))); ?></h3>
                </td>
                <td class="p-4">
                    <h3 class="font-medium"><?php echo e($p->no_telp); ?></h3>
                </td>
                <td class="p-4">
                    <h3 class="font-medium"><?php echo e($p->alamat); ?></h3>
                </td>
                <td class="p-4">
                    <h3 class="font-medium"><?php echo e($p->riwayat_alergi ?? 'Tidak Ada'); ?></h3>
                </td>
                <td class="p-4">
                    <h3 class="font-medium"><?php echo e($p->riwayat_penyakit ?? 'Tidak Ada'); ?></h3>
                </td>
                <td class="p-4">
                    <h3 class="font-medium">
                        <div class="flex flex-row gap-1 items-center">
                            <a href="<?php echo e(route('dashboard.pasien.edit', $p->id)); ?>"
                                class="py-2 px-6 btn text-xs bg-yellow-600 text-white hover:bg-yellow-700 ">
                                Edit
                            </a>
                            <form method="POST" action="<?php echo e(route('dashboard.pasien.destroy', $p->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                    class="py-2 px-6 btn text-xs bg-red-600 text-white hover:bg-red-700 ">
                                    Hapus
                                </button>
                            </form>
                        </div>
                    </h3>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SiSehat\resources\views/admin/pasien/index.blade.php ENDPATH**/ ?>